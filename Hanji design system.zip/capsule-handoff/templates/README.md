# templates/

Astro starting points for the pages on adamr.io, written against Capsule roles
and the repo's real collection schemas (`blog`, `dev`). They are style
references, not a sitemap proposal: where a template disagrees with an existing
page's information architecture, the existing page wins.

| File | Route it's for | The pattern it demonstrates |
| --- | --- | --- |
| `index.astro` | `/` | Hero, ruled credential strip, project sheets, ruled rows, the contact slab |
| `writing-index.astro` | `/blog` | Rows grouped by topic, then a year archive |
| `EssayLayout.astro` | `/blog/[...id]` | The reading register, TOC as a rail, the hatch colophon |
| `dev-detail.astro` | `/dev/[id]` | Case study with a sunken sidecar, stack chips, essay cross-link |
| `photography.astro` | `/photography` | The stack and the page turn, with the full keyboard map |
| `now.astro` | `/now` | A dated status sheet |
| `cv.astro` | `/cv` | A résumé that prints — forces the paper stock, restores it after |
| `links.astro` | `/links` | Rows plus the contact slab |

## Before dropping any of these in

1. **Fix the imports.** They use `@layouts`, `@components`, `@lib`, `@consts`,
   `@types` — match whatever `tsconfig.json` actually defines.
2. **Keep `Layout.astro`.** Every template assumes the existing shell: the
   before-paint stock script, `Head.astro` meta and JSON-LD, header, footer,
   skip link. None of that is re-specified here.
3. **The fluid display clamps are the site's own.** `--text-banner`,
   `--text-display`, `--text-lede` and `--measure` come from `global.css` and
   the templates reference them deliberately. Capsule's `--type-*` steps are
   for chrome, not the editorial display.
4. **Placeholder content is marked.** `now.astro`, `cv.astro` and
   `photography.astro` carry sample entries; the real copy is the author's.
   `cv.astro`'s role history is a plausible skeleton drawn from the site's own
   metadata — check every line before publishing it.

## What these do not include

Pagefind search UI, RSS, the tag pages, poetry, theater, and design archives.
They follow the same parts: rows for lists, sheets for detail, chips for tags,
the rail where an order is real, the slab for a mode. If a surface needs
something not in `css/capsule.components.css`, that is an open item — add it to
`docs/ADAMR-IO-MAPPING.md` rather than inventing a value.
