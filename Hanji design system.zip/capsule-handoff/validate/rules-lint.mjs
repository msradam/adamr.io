#!/usr/bin/env node
// validate/rules-lint.mjs — the rules lint.
// Statically parses the built CSS (token layer + component layer) and fails on:
// any hex not in the primitive allowlist, any border-radius other than 0 on a
// non-control class, any box-shadow, any blur/gradient, any transition/animation
// longer than the single sanctioned beat, and any interactive class missing a
// :focus-visible rule.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { primitiveAllowlist } from './lib/tokens.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const SOURCES = [
  join(HERE, '..', 'tokens', 'capsule.tokens.css'),
  join(HERE, '..', 'css', 'capsule.components.css'),
];
const CSS = SOURCES.map((p) => readFileSync(p, 'utf8')).join('\n');
const SANCTIONED_BEAT_MS = 180;
const INTERACTIVE = ['.capsule-btn', '.capsule-btn--secondary', '.capsule-field__input', '.capsule-nav-item'];

const errors = [];
const stripComments = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '');
const css = stripComments(CSS);

// 1. Hex allowlist. The token-layer --* declarations carry raw primitives;
//    the component layer must reach them only through var().
const allow = primitiveAllowlist();
for (const m of css.matchAll(/#[0-9a-fA-F]{3,8}\b/g)) {
  const hex = m[0].toUpperCase();
  if (!allow.has(hex)) errors.push(`Disallowed hex ${hex} (not a primitive token).`);
}

// 2. Radius: surfaces are square (0); only control classes may be pills
//    (chip / tag / toggle / switch / fab / key / pill — detached pressable controls).
const CONTROL_RE = /(chip|tag|toggle|switch|fab|key|pill)/i;
for (const rule of css.matchAll(/([^{}]+)\{([^}]*)\}/g)) {
  const selector = rule[1].trim(), body = rule[2];
  for (const m of body.matchAll(/border-radius\s*:\s*([^;]+);/g)) {
    const v = m[1].trim();
    if (/^(0px|0|var\(--radius-surface\))$/.test(v)) continue;
    if (/^(999px|9999px|50%|var\(--radius-control\))$/.test(v) && CONTROL_RE.test(selector)) continue;
    errors.push(`border-radius ${v} on "${selector.slice(0, 40)}" — surfaces must be 0; pills only on control classes.`);
  }
}

// 3. No elevation vocabulary.
if (/box-shadow\s*:/.test(css)) errors.push('box-shadow present — elevation banned.');
if (/filter\s*:\s*[^;]*blur/.test(css)) errors.push('blur filter present — banned.');
// Gradient is banned in paint. The hatch pattern is the one sanctioned use and
// lives only in the --pattern-hatch token declaration.
const gradients = [...css.matchAll(/(linear|radial|conic)-gradient/g)];
const hatchDecls = [...css.matchAll(/--pattern-hatch\s*:[^;]*gradient/g)];
if (gradients.length > hatchDecls.length) errors.push('gradient present outside the --pattern-hatch token — banned.');

// 4. Motion budget: no transition/animation duration over the sanctioned beat.
for (const d of css.matchAll(/(?:transition|animation)[^;{}]*?(\d+(?:\.\d+)?)(ms|s)/g)) {
  const ms = parseFloat(d[1]) * (d[2] === 's' ? 1000 : 1);
  if (ms > SANCTIONED_BEAT_MS) errors.push(`Motion ${ms}ms exceeds the ${SANCTIONED_BEAT_MS}ms sanctioned beat.`);
}

// 5. Every interactive class must have a :focus-visible rule.
for (const sel of INTERACTIVE) {
  const re = new RegExp(sel.replace(/[.\-]/g, '\\$&') + ':focus-visible');
  if (!re.test(css)) errors.push(`${sel} has no :focus-visible rule.`);
}

console.log('\nCAPSULE RULES LINT — tokens/capsule.tokens.css + css/capsule.components.css\n');
if (errors.length) { for (const e of errors) console.error('  \u2717 ' + e); console.error(`\n${errors.length} rule violation(s). Build blocked.\n`); process.exit(1); }
console.log('  \u2713 hex allowlist  \u2713 radius (surfaces 0, controls pill)  \u2713 no elevation  \u2713 motion budget  \u2713 focus-visible on all interactive classes\n');
